<?php
class qCal_DateTime_Exception_InvalidWeekday extends qCal_DateTime_Exception {

	// w00t!

}